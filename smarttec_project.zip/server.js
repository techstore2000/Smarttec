// Platzhalter für Node.js Server
console.log('Smarttec Backend aktiv');