# Smarttec

Einfaches Finanzverwaltungs-Tool mit Login, Datenverwaltung, PDF/Excel-Export.

## Funktionen
- Login (Admin: Nadim / Passwort: Midanmirzazada1984@@)
- Einnahmen, Ausgaben, Guthaben erfassen
- Monatlich anzeigen
- Suchen nach Datum
- PDF & Excel exportieren
- Benutzerverwaltung

## Start (lokal)
```bash
npm install
npm run dev
```